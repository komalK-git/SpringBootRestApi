package com.example.demo.sevice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.binding.Course;
import com.example.demo.binding.repo.CourseRepository;
import com.example.demo.service.CourseService;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseRepository courseRepository;
	
	@Override
	public String upsert(Course course) {
		courseRepository.save(course);
		return "success";
	}

	@Override
	public Course getByID(Integer id) {
		Optional<Course> findById =courseRepository.findById(id);
		if(findById.isPresent()) {
			return findById.get();
		}
		return null;
	}

	@Override
	public List<Course> getAllCourse() {
		return courseRepository.findAll();
	}

	@Override
	public String deleteById(Integer id) {
		if(courseRepository.existsById(id)){
			courseRepository.deleteById(id);	
			return "Deleted successfully";
		}
		else {
			return "no record found";
		}
	
	}

}
