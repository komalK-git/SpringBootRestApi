package com.example.demo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.binding.Course;
import com.example.demo.service.CourseService;

import jakarta.persistence.GeneratedValue;

@RestController
public class CourseRestController {

	@Autowired
	CourseService courseService;
	
	@PostMapping("/course")
	private ResponseEntity<String> createCourse(@RequestBody Course course){
		String status=courseService.upsert(course);
		return new ResponseEntity<>(status,HttpStatus.CREATED);
		
	}
	
	@GetMapping("/course/{id}")
	private ResponseEntity<Course> getCourse(@PathVariable Integer id){
		Course course = courseService.getByID(id);
		return new ResponseEntity<>(course,HttpStatus.OK);
	}
	
	@GetMapping("/courses")
	public ResponseEntity<List<Course>> getAllCourse(){
		List<Course> allcourse=courseService.getAllCourse();
		return new ResponseEntity<>(allcourse, HttpStatus.OK);
	}
	
	@PutMapping("/course/update")
	public ResponseEntity<String> updateCourse(@RequestBody Course course){
		String status = courseService.upsert(course);
		return new ResponseEntity<String>(status,HttpStatus.CREATED);
	}
	
	@DeleteMapping("/course/{id}")
	public ResponseEntity<String> deleteCourse(@PathVariable Integer id){
		String deleteById = courseService.deleteById(id);
		return new ResponseEntity<>(deleteById,HttpStatus.OK);
	}
}
